﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Security;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using System.IO.Compression;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;

namespace BitExpressDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string priKey = @"-----BEGIN RSA PRIVATE KEY-----
            MIIEowIBAAKCAQEAyFoGHP3VTcjh9lRHx2JNv9P+HDW6VDMNlLwCA2bFbSZrY5J3
            f4lzUBRFL9cX62yfWvkm18FRTIeUK+NIaUL4y1hhd0JsuM65xrn1wipf0lTOdzOz
            87Y3sav2YWIsGuH8dh8WmCZ0fMfU/TC3/i4a2VdBY34hPqEZ0rryv9zX79lkY9SF
            jABTsirTAv43f9OjQRIrBH0Zr33zVgbD2ASanIWLyHFePXRr5g49JALh0ShGnnoG
            1/dQ4vsF+b3KJxy5ZKK0uy6bysabHFmCHoJs5aM1SRvdJlgO6IgRtGfXFael4eFc
            vy0oHZ+SFk5WFWGuZHCQfBEZJW5pizRYASPT+wIDAQABAoIBAA5/JQ4X98UnEeKG
            +qKcpE+LAUn9QTwybXsjl2mzl/lr3D1aLbdWtLdIoDDz+VEZjPZCLONTo5RMAxah
            3W1wYRwlivfcII3Gt35/mh6wfjpz1HSfkxfBSYpbjPpC5joTu/a4DSR5M9iLhQfE
            7KtBnsO3Io4WZEVp1rp+uG3VhvJdwbWhsUsBj1cZomZo8YCEaY8gaQacyTXrZUdb
            dEK6NYHNGUL2iRFgFjTqs6IVUL+CKmxeirmqSVLKlhRWr6oBdgVmnEkjdLMwn3t0
            nrXZeGuZBBFgOGH2aUeUbYOlKgV7/z084XyVmoqnzmDmmUR95bnwx/cKxsA3Rve4
            AQ7zr5ECgYEA41e7yRc9K4e6q2tbfQP5d0yxS2Axl9ZjizRiQHKfhgPnny8XIfJr
            5il1GYn1t4ddGLC5txZpFLxz9Dj8AQvgRQ0juSPdqsIqY5ugjGm/RcaydYx35Gzh
            vrdrwAoET4a0obK8sddbd/PfFz0jqwpCNEnrxfTIwSAldlwRoPt6ZFUCgYEA4ZtM
            gzGO4U0LViAlmC2T4NTaOaJ4N4aUkMvED7+90fowtTTXlqt/UDyaZ7B1UAijO9QA
            ftIFRiI2sRGWDppB9aUX4xhbGXzukAj6DrroLCNKKtLCUxYqqpB3EFbISOZnsbxB
            WU7fcpr+uTeyYQYzjEBjpibS/XyzITvuhdfzJw8CgYEAotvipjeDln9w9gO+Ulxa
            hV/nUjviywbF4J7yE4EJThPWBW7Sf3sOWJ8yR81QvNy3kExpfgML29L0ret0e7tq
            OY0kHijXTtAxVZHS/UNzxiSFCzhJWtW1Ec6L3dJPLDkvhPZpvmysFc4Z7qfZuVlr
            +9FImVK1zcOdkqB58Hy2PNECgYB7854zCnxs7q6G0Dy3gnsX8PpA5jHUl/1yHHIJ
            ERjSj/pI5NJ6NplJVTKkO4AIy+YbTdxD0VISeWPBH19pgHky5FTecZhDxa8wta3l
            f+1lqrHqG0em7KvecGbqNDPwUZ6xOTRSRBJiXiQLUT2RLx4NNadKN1R+7w9f+BSR
            ttciIwKBgCEE5q6P1uhwormvzTHRxFeiuvQszQKLPodw+USGOzZUYverWkZKmpPz
            8W0lzY7NG/bKCbHeXrjsnsRZbmoUDFbM45yx+h0dSHTpe0M4MAFTTbMubnqo8CYA
            ptQhci6qbrQNdgHTrAqyCAVklAaSuaCmrljcsTEthIniIIaURjYF
            -----END RSA PRIVATE KEY-----";

            string pubKey = @"-----BEGIN PUBLIC KEY-----
            MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuQ69HDFzFxlUVeQJM5Nj
            JeGAWOmglpFgcwxxF2rZseu6aq8c1oz5wtcQwNTN9OeJEYsmrmSkRrxoLkRBeFSd
            nJLngQ42Ynnpo6d1TPxI7GcB2VqKEqmhXLTE4HYaa64Rcl9N5+g2uQwAA3uc0OnT
            z5tYgyrC9ZYX3xNjqfgX2jhNRKo+Feo0ICNcEy8mP60ih3ON+DUuDefv0z3nPQY+
            Znm+1jIURL7yiBi9bmUamPduDNDs/wxOJkgfIKWFPx75EdOiS+xWewdPF2PczRSB
            Of5LVOgimEA5Um0TprHe0Zcp1vnsZ6tPsR2fvEM8qdV4LCAc/b8qv3FxNXhtSo9O
            9wIDAQAB
            -----END PUBLIC KEY-----";

            priKey = priKey.Replace("-----BEGIN RSA PRIVATE KEY-----", "")
                .Replace("-----END RSA PRIVATE KEY-----", "");
            pubKey = pubKey.Replace("-----BEGIN PUBLIC KEY-----", "")
                .Replace("-----END PUBLIC KEY-----", "");

            RsaHelper rsaHelper = new RsaHelper();
            Console.OutputEncoding = System.Text.Encoding.Default;
            string url = "https://www.bitexpress.io/api/gateway.do";
            JObject dicheader = new JObject();
            dicheader.Add(new JProperty("requestTime", "2019-04-23T19:56:59.444+0800"));
            dicheader.Add(new JProperty("service", "plus"));
            dicheader.Add(new JProperty("serviceVersion", "1.0"));
            JObject dicBody = new JObject();
            dicBody.Add(new JProperty("a", "1"));
            dicBody.Add(new JProperty("b", "2"));
            dicBody.Add(new JProperty("time", "2019-04-23T19:56:59.442+0800"));
            JObject dic = new JObject();
            dic.Add(new JProperty("header", dicheader));
            dic.Add(new JProperty("body", dicBody));
            string requestParams = Convert.ToString(dic).Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\\", "");
            Console.WriteLine("签名参数是：");
            Console.WriteLine(requestParams);
            string signature = rsaHelper.Sign(requestParams, priKey);
            Console.WriteLine("算出来的结果是：");
            Console.WriteLine(signature);
            Dictionary<string, string> dicContent=new Dictionary<string,string>();
            dicContent.Add("uid", "174");
            dicContent.Add("signature", signature);
            dicContent.Add("signatureVersion", "1.0");
            dicContent.Add("content", requestParams);

            HttpWebRequest request = null;
            request = WebRequest.Create(url) as HttpWebRequest;
            request.ProtocolVersion = HttpVersion.Version10;
            request.Method = "POST";
            request.ContentType = "application/json; charset=utf-8";
            //request.ContentType = "application/x-www-form-urlencoded; charset=utf-8";
            string contentJson = JsonConvert.SerializeObject(dicContent, Formatting.Indented);
            Console.WriteLine("开始推送到网关数据：");
            Console.WriteLine(contentJson);
            byte[] data = Encoding.GetEncoding("utf-8").GetBytes(contentJson);
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            HttpWebResponse response = request.GetResponse() as HttpWebResponse;
            //打印返回值  
            Stream repStream = response.GetResponseStream();   //获取响应的字符串流  
            StreamReader sr = new StreamReader(repStream); //创建一个stream读取流  
            string html = sr.ReadToEnd();   //从头读到尾，放到字符串html  
            Console.Write("获取到网关返回信息：");
            Console.WriteLine(html);
            Console.Write("按任意键退出");
            Console.ReadKey(true);
        }
    }
}
